<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <h1>About Me</h1>
            <p>Hello, my name is Alviona Caroline.</p>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>